#include "stdafx.h"
#include "MQM Truck.h"
#include "MQM TruckDlg.h"
#include "afxdialogex.h"
#include "mshtml.h"
#include "Ping.h"
#include "base64.h"
#include "CSmtp.h"
#include "lmdns.h"
#include "tinyxml2.h"
#include <vector>
#include <deque>
#include <regex>


#pragma comment( lib, "libssl.lib" )
#pragma comment( lib, "libcrypto.lib" )
#pragma comment( lib, "Crypt32.lib" )


using namespace std;
using namespace tinyxml2;


#ifdef _DEBUG
#define new DEBUG_NEW
#endif


BEGIN_MESSAGE_MAP(CCTDlg, CDialog)
    ON_WM_PAINT()
    ON_WM_QUERYDRAGICON()
    ON_WM_SIZE()
    ON_WM_TIMER()
    ON_WM_DESTROY()
    ON_BN_CLICKED(IDC_PAUSE_BTN, &CCTDlg::OnBnClickedPauseBtn)
    ON_BN_CLICKED(IDC_RESUME_BTN, &CCTDlg::OnBnClickedResumeBtn)
END_MESSAGE_MAP()


CRITICAL_SECTION globallock;
CRITICAL_SECTION datalock;
CRITICAL_SECTION loglock;


std::deque<std::wstring> black_clouds;
std::deque<std::wstring> white_clouds;
std::deque<std::wstring> colorful_clouds;
std::vector<std::string> trace_logs;
std::vector<std::string> truck_list;
std::vector<std::string> truck_names;

volatile BOOL truck_terminated = FALSE;
volatile BOOL truck_paused = FALSE;


//wstring to string
string ws2s(const wstring &ws)
{
    const wchar_t *_Source = ws.c_str();
    size_t _Dsize = 2 * ws.size() + 1;
    char *_Dest = new char[_Dsize];
    memset(_Dest, 0, _Dsize);
    wcstombs(_Dest, _Source, _Dsize);
    string result = _Dest;
    delete []_Dest;
    return result;
}


//string to wstring
wstring s2ws(const string &s)
{
    const char *_Source = s.c_str();
    size_t _Dsize = s.size() + 1;
    wchar_t *_Dest = new wchar_t[_Dsize];
    wmemset(_Dest, 0, _Dsize);
    mbstowcs(_Dest, _Source, _Dsize);
    wstring result = _Dest;
    delete []_Dest;
    return result;
}


string GetConfigKeyValue(LPSTR catalog, LPSTR key = NULL)
{
    string result;
    tinyxml2::XMLDocument xml;
    XMLElement *root[3] = {NULL, NULL, NULL};
    XMLError ret = xml.LoadFile("MQM Truck.xml");

    if (ret == XML_SUCCESS)
    {
        root[0] = xml.FirstChildElement("config");

        if (root[0] != NULL)
        {
            root[1] = root[0]->FirstChildElement(catalog);

            if (root[1] != NULL)
            {
                if (key != NULL)
                {
                    root[2] = root[1]->FirstChildElement(key);

                    if (root[2] != NULL)
                    {
                        result = string(root[2]->GetText());
                    }
                }
                else
                {
                    result = string(root[1]->GetText());
                }
            }
        }
    }

    return result;
}


string GetConfigKeyProperty(LPSTR catalog, LPSTR key, LPSTR property)
{
    string result;
    tinyxml2::XMLDocument xml;
    XMLElement *root[3] = {NULL, NULL, NULL};
    XMLError ret = xml.LoadFile("MQM Truck.xml");

    if (ret == XML_SUCCESS)
    {
        root[0] = xml.FirstChildElement("config");

        if (root[0] != NULL)
        {
            root[1] = root[0]->FirstChildElement(catalog);

            if (root[1] != NULL)
            {
                root[2] = root[1]->FirstChildElement(key);

                if (root[2] != NULL)
                {
                    result = string(root[2]->Attribute(property));
                }
            }
        }
    }

    return result;
}


BOOL GetUniqueTempFileName(LPTSTR path, LPTSTR prefix, ULONGLONG unique_id, LPTSTR tempname)
{
    if (
        (path != NULL && path[0] != _T('\0')) &&
        (prefix != NULL && prefix[0] != _T('\0')) &&
        (tempname != NULL) &&
        (unique_id != 0ULL)
    )
    {
        CString filename;
        time_t ltime = (time_t)0LL;
        time(&ltime);

        if (ltime != 0LL)
        {
            filename.Format(_T("%s%s_%016I64X%016I64X.tmp"), path, prefix, (long long)ltime, unique_id);
            _tcscpy_s(tempname, MAX_PATH, filename.GetBuffer());
            tempname[MAX_PATH - 1] = _T('\0');
            return (tempname[0] != _T('\0'));
        }
    }

    return FALSE;
}


CString GetItemPayloadType(string &item)
{
#define HDR_CASE_TYPE(signature, header) do {\
        if (strcmp(signature.c_str(), header) == 0)\
        {\
            return CString(_T(header));\
        }\
    } while (0)

    if (!item.empty())
    {
        int pos;

        if (item.length() > (sizeof(STAT_POLL) / sizeof(STAT_POLL[0])))
        {
            pos = item.find("\r\n");

            if (pos != string::npos)
            {
                string hdr = item.substr(0, pos);
                HDR_CASE_TYPE(hdr, STAT_PUSH);
                HDR_CASE_TYPE(hdr, STAT_POLL);
                HDR_CASE_TYPE(hdr, QVD_PUSH);
                HDR_CASE_TYPE(hdr, QVD_POLL);
                HDR_CASE_TYPE(hdr, JSON_PUSH);
                HDR_CASE_TYPE(hdr, JSON_POLL);
                HDR_CASE_TYPE(hdr, EMAIL_PUSH);
                HDR_CASE_TYPE(hdr, EMAIL_POLL);
            }
        }
    }

    return CString();
}


CString FormatSpaceSize(ULONGLONG size)
{
    float val;
    CString result;

    if (size > TRUCK_TERA)
    {
        val = (float)size / (float)TRUCK_TERA;
        result.Format(_T("%6.3fT"), val);
    }
    else if (size > TRUCK_GIGA)
    {
        val = (float)size / (float)TRUCK_GIGA;
        result.Format(_T("%6.3fG"), val);
    }
    else if (size > TRUCK_MEGA)
    {
        val = (float)size / (float)TRUCK_MEGA;
        result.Format(_T("%6.3fM"), val);
    }
    else if (size > TRUCK_KILO)
    {
        val = (float)size / (float)TRUCK_KILO;
        result.Format(_T("%6.3fK"), val);
    }
    else
    {
        val = (float)size;
        result.Format(_T("%6.3fB"), val);
    }

    return result;
}


CString FormatDateTime(ULONGLONG delta)
{
    CString result;

    if (delta >= TRUCK_DAY)
    {
        ULONGLONG d = delta / TRUCK_DAY;
        ULONGLONG h = (delta % TRUCK_DAY) / TRUCK_HOUR;
        result.Format(_T("%llud%lluh"), d, h);
    }
    else if (delta >= TRUCK_HOUR)
    {
        ULONGLONG h = delta / TRUCK_HOUR;
        ULONGLONG m = (delta % TRUCK_HOUR) / TRUCK_MINUTE;
        result.Format(_T("%lluh%llum"), h, m);
    }
    else if (delta >= TRUCK_MINUTE)
    {
        ULONGLONG m = delta / TRUCK_MINUTE;
        ULONGLONG s = (delta % TRUCK_MINUTE) / TRUCK_SECOND;
        result.Format(_T("%llum%llus"), m, s);
    }
    else if (delta >= TRUCK_SECOND)
    {
        ULONGLONG s = delta / TRUCK_SECOND;
        result.Format(_T("%llus"), s);
    }
    else
    {
        result = CString(_T("0m0s"));
    }

    return result;
}


string GetFieldContent(string &source, LPSTR key)
{
    size_t poss;
    size_t pose;
    CStringA it;
    string ret;
    assert(key != NULL);
    it.Format("\r\n%s:", key);
    poss = source.find(it.GetBuffer());

    if (poss != std::string::npos)
    {
        pose = source.find("\r\n", poss + it.GetLength());

        if (pose != std::string::npos)
        {
            ret = source.substr(poss + it.GetLength(), pose - poss - it.GetLength());
        }
    }

    return ret;
}


string ResolveName(char *host)
{
    CStringA hostname(host);
    CStringA record;
    EnterCriticalSection(&globallock);
    record = lmdns_query(hostname);
    LeaveCriticalSection(&globallock);

    if (!record.IsEmpty())
    {
        return std::string(record.GetBuffer());
    }

    assert((host != NULL) && (host[0] != '\0'));

    if (lmdns_valid_host(hostname)) /* domain name */
    {
        char ip[MAX_PATH];
        BOOL resolved = FALSE;
        struct hostent *he;
        struct in_addr **addr_list;
        he = gethostbyname(host);

        if (he != NULL)
        {
            addr_list = (struct in_addr **) he->h_addr_list;

            for (int i = 0; addr_list[i] != NULL; i++)
            {
                int dc = 0;
                strcpy(ip, inet_ntoa(*addr_list[i]));

                for (int j = 0; j < (sizeof("111.111.111.111") - 1); j++)
                {
                    if (ip[j] == '\0')
                    {
                        break;
                    }
                    else if (ip[j] == '.')
                    {
                        dc++;
                    }
                }

                if (dc == 3)
                {
                    resolved = TRUE;
                    break;
                }
            }
        }

        if (resolved)
        {
            return std::string(ip);
        }
        else
        {
            return std::string();
        }
    }
    else
    {
        if (lmdns_valid_ip(hostname))
        {
            return std::string(host);
        }
        else
        {
            return std::string();
        }
    }
}


void mt_debug(CHAR *format, ... )
{
    EnterCriticalSection(&loglock);
    va_list arglist;
    static CHAR msg_buffer[INT16_MAX];
    va_start(arglist, format);
    vsnprintf(msg_buffer, ((sizeof(msg_buffer) / sizeof(msg_buffer[0])) - 1), format, arglist);
    msg_buffer[((sizeof(msg_buffer) / sizeof(msg_buffer[0])) - 1)] = _T('\0');
    va_end(arglist);

    if (msg_buffer[0] != '\0')
    {
        trace_logs.push_back(std::string(msg_buffer));
    }

    LeaveCriticalSection(&loglock);
}


void CCTDlg::DoDataExchange(CDataExchange *pDX)
{
    CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_MESSAGE, m_message);
    DDX_Control(pDX, IDC_INFOMATION_FRAME, m_information_frame);
    DDX_Control(pDX, IDC_BOTTOM, m_bottom_logo);
    DDX_Control(pDX, IDC_PAUSE_BTN, m_pause);
    DDX_Control(pDX, IDC_RESUME_BTN, m_resume);
    DDX_Control(pDX, IDC_INCOMING_BOX, m_incoming);
    DDX_Control(pDX, IDC_INIDLE_BOX, m_inidle);
    DDX_Control(pDX, IDC_OUTCOMING_BOX, m_outcoming);
    DDX_Control(pDX, IDC_OUTIDLE_BOX, m_outidle);
    DDX_Control(pDX, IDC_CLIENTS_BOX, m_clients);
    DDX_Control(pDX, IDC_COLLECTORS_BOX, m_collectors);
    DDX_Control(pDX, IDC_SPACE_BOX, m_space);
}


CCTDlg::CCTDlg(CWnd *pParent /*=NULL*/)
    : CDialog(IDD_CCT_DIALOG, pParent)
{
    int id = 0;
    CStringA ns_key;
    lmdns_init();

    do
    {
        ns_key.Format("RECORD%d", id);
        string ip = GetConfigKeyValue("DNS", ns_key.GetBuffer());

        if (!ip.empty())
        {
            string hostname = GetConfigKeyProperty("DNS", ns_key.GetBuffer(), "HOSTNAME");

            if (!hostname.empty())
            {
                CStringA ips(ip.c_str());
                CStringA host(hostname.c_str());
                ips = ips.Trim();
                host = host.Trim();

                if ((!ips.IsEmpty()) && (!host.IsEmpty()))
                {
                    lmdns_add(ips, host);
                }
                else
                {
                    break;
                }
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }

        id++;
    }
    while (TRUE);

    id = 0;
    m_vidata_servers.clear();
    m_vidata_servers.shrink_to_fit();

    do
    {
        ns_key.Format("VIDATA%d", id);
        string ip = GetConfigKeyValue("SERVER", ns_key.GetBuffer());

        if (!ip.empty())
        {
            string user = GetConfigKeyProperty("SERVER", ns_key.GetBuffer(), "USER");
            string pass = GetConfigKeyProperty("SERVER", ns_key.GetBuffer(), "PASS");
            string home = GetConfigKeyProperty("SERVER", ns_key.GetBuffer(), "HOME");
            string hostname = GetConfigKeyProperty("SERVER", ns_key.GetBuffer(), "HOSTNAME");
            CStringA cs_user(user.c_str());
            CStringA cs_pass(pass.c_str());
            CStringA cs_home(home.c_str());
            CStringA cs_hostname(hostname.c_str());
            CStringA cs_ip(ip.c_str());
            cs_user = cs_user.Trim();
            cs_pass = cs_pass.Trim();
            cs_home = cs_home.Trim();
            cs_hostname = cs_hostname.Trim();
            cs_ip = cs_ip.Trim();

            if ((!cs_user.IsEmpty()) && (!cs_pass.IsEmpty()) && (!cs_home.IsEmpty()) && (!cs_hostname.IsEmpty()) && (!cs_ip.IsEmpty()))
            {
                CStringA vidata;
                vidata.Format("VIDATA\r\nUSER:%s\r\nPASS:%s\r\nHOME:%s\r\nHOSTNAME:%s\r\nIP:%s\r\n\r\n", cs_user.GetBuffer(), cs_pass.GetBuffer(), cs_home.GetBuffer(), cs_hostname.GetBuffer(), cs_ip.GetBuffer());
                m_vidata_servers += string(vidata.GetBuffer());
            }
            else
            {
                break;
            }
        }
        else
        {
            break;
        }

        id++;
    }
    while (TRUE);

    string log_ota = GetConfigKeyValue("LOGOTA");

    if (!log_ota.empty())
    {
        CStringA ota(log_ota.c_str());
        ota.MakeLower();
        m_log_ota = ((ota.Find("true") >= 0) || (ota.Find("yes") >= 0) || (ota.Find("always") >= 0));
    }

    m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
    memset(cct_temppath, 0, sizeof(cct_temppath));

    if (GetTempPath(sizeof(cct_temppath) / sizeof(cct_temppath[0]), cct_temppath))
    {
        CStringW path(cct_temppath);
        path.Replace(_T('/'), _T('\\'));
        int pos = path.ReverseFind(_T('\\'));

        if (pos > 0)
        {
            int ret;
            int err;
            path.Insert(pos, _T("Truck"));
            _tcscpy_s(cct_temppath, sizeof(cct_temppath) / sizeof(cct_temppath[0]), path.GetBuffer());
            ret = _tmkdir(cct_temppath);

            if (ret != ERROR_SUCCESS)
            {
                err = errno;
                assert(err == EEXIST);
            }

            if (cct_temppath[0] != _T('\0'))
            {
                CStringW folder;

                for (int i = 0; i <= 0xFF; i++)
                {
                    folder.Format(_T("%s%02X\\"), cct_temppath, i);
                    ret = _tmkdir(folder.GetBuffer());

                    if (ret != ERROR_SUCCESS)
                    {
                        err = errno;
                        assert(err == EEXIST);
                    }
                }
            }
            else
            {
                assert(0);
            }
        }
        else
        {
            assert(0);
        }
    }
    else
    {
        assert(0);
    }

#if (defined(TRUCK_SERVER_NAME0) && defined(TRUCK_SERVER_IP0))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME0));
#endif
#if (defined(TRUCK_SERVER_NAME1) && defined(TRUCK_SERVER_IP1))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME1));
#endif
#if (defined(TRUCK_SERVER_NAME2) && defined(TRUCK_SERVER_IP2))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME2));
#endif
#if (defined(TRUCK_SERVER_NAME3) && defined(TRUCK_SERVER_IP3))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME3));
#endif
#if (defined(TRUCK_SERVER_NAME4) && defined(TRUCK_SERVER_IP4))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME4));
#endif
#if (defined(TRUCK_SERVER_NAME5) && defined(TRUCK_SERVER_IP5))
    truck_names.push_back(std::string(TRUCK_SERVER_NAME5));
#endif
    truck_names.shrink_to_fit();
}


BOOL CCTDlg::OnInitDialog()
{
    CDialog::OnInitDialog();
    // Set the icon for this dialog.  The framework does this automatically
    //  when the application's main window is not a dialog
    SetIcon(m_hIcon, TRUE);			// Set big icon
    SetIcon(m_hIcon, FALSE);		// Set small icon
    ::InitializeCriticalSection(&globallock);
    ::InitializeCriticalSection(&datalock);
    ::InitializeCriticalSection(&loglock);

    if (m_message.m_hWnd != NULL)
    {
        CHARFORMAT cfm;
        cfm.cbSize = sizeof(cfm);
        cfm.dwMask = CFM_FACE;
        _tcscpy_s(cfm.szFaceName, sizeof(cfm.szFaceName) / sizeof(cfm.szFaceName[0]), _T("Consolas"));

        if (!m_message.SetDefaultCharFormat(cfm))
        {
            _tcscpy_s(cfm.szFaceName, sizeof(cfm.szFaceName) / sizeof(cfm.szFaceName[0]), _T("Lucida Console"));
            m_message.SetDefaultCharFormat(cfm);
        }
    }

    if (m_hWnd != NULL)
    {
        GetWindowText(m_caption);
        UpdateUiStatus(FALSE);

        if (m_incoming.m_hWnd != NULL)
        {
            m_incoming.SetWindowText(_T("0KB"));
        }

        if (m_inidle.m_hWnd != NULL)
        {
            m_inidle.SetWindowText(_T("0m0s"));
            m_incoming_idle = GetTickCount64();
        }

        if (m_outcoming.m_hWnd != NULL)
        {
            m_outcoming.SetWindowText(_T("0KB"));
        }

        if (m_outidle.m_hWnd != NULL)
        {
            m_outidle.SetWindowText(_T("0m0s"));
            m_outcoming_idle = GetTickCount64();
        }

        if (m_clients.m_hWnd != NULL)
        {
            m_clients.SetWindowText(_T("0"));
        }

        if (m_collectors.m_hWnd != NULL)
        {
            m_collectors.SetWindowText(_T("0"));
        }

        if (m_space.m_hWnd != NULL)
        {
            ULARGE_INTEGER FreeBytesAvailableToCaller;
            ULARGE_INTEGER TotalNumberOfBytes;
            ULARGE_INTEGER TotalNumberOfFreeBytes;

            if (GetDiskFreeSpaceEx(cct_temppath, &FreeBytesAvailableToCaller, &TotalNumberOfBytes, &TotalNumberOfFreeBytes))
            {
                m_free_space = FreeBytesAvailableToCaller.QuadPart;
                CString AvailableSpace = FormatSpaceSize(m_free_space);
                m_space.SetWindowText(AvailableSpace);
            }
            else
            {
                m_space.SetWindowText(_T("N/A"));
            }
        }
    }

    InitializeWinsock2();
    CHAR deamon_name[MAX_PATH];
    memset(deamon_name, 0, sizeof(deamon_name));
    memset(cct_hostname, 0, sizeof(cct_hostname));

    if (gethostname(deamon_name, sizeof(deamon_name)) == ERROR_SUCCESS)
    {
        string hostname(deamon_name);
        assert(hostname.length() < MAX_PATH);
        wstring whostname = s2ws(hostname);
        _tcscpy_s(cct_hostname, sizeof(cct_hostname) / sizeof(cct_hostname[0]), whostname.c_str());

        if (m_information_frame.m_hWnd != NULL)
        {
            m_information_frame.SetWindowText(cct_hostname);
        }
    }
    else
    {
        assert(0);
    }

    if (cct_temppath[0] != _T('\0'))
    {
        CString mask;
        CString sFilePath;
        CString sFileTitle;
        ULONGLONG length;
        CFileFind ff;
        BOOL bFound;

        for (int i = 0; i <= 0xFF; i++)
        {
            mask.Format(_T("%s%02X\\*.tmp"), cct_temppath, i);
            bFound = ff.FindFile(mask.GetBuffer());

            while (bFound)
            {
                bFound = ff.FindNextFile();
                sFilePath = ff.GetFilePath();
                sFileTitle = ff.GetFileTitle();
                length = ff.GetLength();

                if ((!ff.IsDirectory()) && (!ff.IsDots()))
                {
                    if (length != 0ULL)
                    {
                        if (sFileTitle.Find(_T(QVD_PUSH)) >= 0)
                        {
                            black_clouds.push_back(std::wstring(sFilePath.GetBuffer()));
                            m_incoming_total += ff.GetLength();
                        }
                        else if (sFileTitle.Find(_T(JSON_PUSH)) >= 0)
                        {
                            white_clouds.push_back(std::wstring(sFilePath.GetBuffer()));
                            m_incoming_total += ff.GetLength();
                        }
                        else if (sFileTitle.Find(_T(EMAIL_PUSH)) >= 0)
                        {
                            colorful_clouds.push_back(std::wstring(sFilePath.GetBuffer()));
                            m_incoming_total += ff.GetLength();
                        }
                        else
                        {
                            SetFileAttributes(sFilePath.GetBuffer(), FILE_ATTRIBUTE_NORMAL);
                            DeleteFile(sFilePath.GetBuffer());
                        }
                    }
                    else
                    {
                        SetFileAttributes(sFilePath.GetBuffer(), FILE_ATTRIBUTE_NORMAL);
                        DeleteFile(sFilePath.GetBuffer());
                    }
                }
            }
        }

        ff.Close();
    }

    /* Create a thread for incoming */
    ULONGLONG anchor = GetTickCount64();

    do
    {
        m_incoming_thread = AfxBeginThread((AFX_THREADPROC)DataIncomingThread, (LPVOID)this, THREAD_PRIORITY_NORMAL);

        if (m_incoming_thread == NULL)
        {
            Sleep(USER_TIMER_MINIMUM);
        }
    }
    while ((!truck_terminated) && (m_incoming_thread == NULL) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

    assert(m_incoming_thread != NULL);
    m_incoming_thread->m_bAutoDelete = TRUE;
    /* Create a thread for outcoming */
    anchor = GetTickCount64();

    do
    {
        m_outcoming_thread = AfxBeginThread((AFX_THREADPROC)DataOutcomingThread, (LPVOID)this, THREAD_PRIORITY_NORMAL);

        if (m_outcoming_thread == NULL)
        {
            Sleep(USER_TIMER_MINIMUM);
        }
    }
    while ((!truck_terminated) && (m_outcoming_thread == NULL) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

    assert(m_outcoming_thread != NULL);
    m_outcoming_thread->m_bAutoDelete = TRUE;
    /* Create a thread for control */
    anchor = GetTickCount64();

    do
    {
        m_control_thread = AfxBeginThread((AFX_THREADPROC)ControlThread, (LPVOID)this, THREAD_PRIORITY_NORMAL);

        if (m_control_thread == NULL)
        {
            Sleep(USER_TIMER_MINIMUM);
        }
    }
    while ((!truck_terminated) && (m_control_thread == NULL) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

    assert(m_control_thread != NULL);
    m_control_thread->m_bAutoDelete = TRUE;
    debug( LVL_D, _T("Build date: %s %s"), _T(__DATE__), _T(__TIME__));
    debug( LVL_D, _T("Build version: %s"), _T(MQM_VERSION));
    SetTimer(1, MAX_PATH, NULL);
    return TRUE;  // return TRUE  unless you set the focus to a control
}


void CCTDlg::UpdateUiStatus(BOOL paused)
{
    CTime ctm = CTime::GetCurrentTime();
    CString tm = ctm.Format(_T(" (%B %d, %Y %H:%M:%S)"));
    CString caption;

    if (paused)
    {
        m_pause.EnableWindow(FALSE);
        m_bottom_logo.ShowWindow(SW_HIDE);
        m_resume.EnableWindow(TRUE);
        caption.Format(_T("%s - PAUSED"), m_caption.GetBuffer());
    }
    else
    {
        m_pause.EnableWindow(TRUE);
        m_bottom_logo.ShowWindow(SW_SHOW);
        m_resume.EnableWindow(FALSE);
        caption.Format(_T("%s - RUNNING"), m_caption.GetBuffer());
    }

    caption += tm;
    SetWindowText(caption);
}


void CCTDlg::OnBnClickedPauseBtn()
{
    UpdateUiStatus(TRUE);
    EnterCriticalSection(&globallock);
    truck_paused = TRUE;
    LeaveCriticalSection(&globallock);

    if (m_incoming_thread != NULL)
    {
        ::WaitForSingleObject(m_incoming_thread->m_hThread, INFINITE);
        m_incoming_thread = NULL;
    }
}


void CCTDlg::OnBnClickedResumeBtn()
{
    UpdateUiStatus(FALSE);
    m_idle_notified = FALSE;
    EnterCriticalSection(&globallock);
    truck_paused = FALSE;
    LeaveCriticalSection(&globallock);

    if (m_incoming_thread == NULL)
    {
        mt_debug("User request resume");
        ULONGLONG anchor = GetTickCount64();

        do
        {
            m_incoming_thread = AfxBeginThread((AFX_THREADPROC)DataIncomingThread, (LPVOID)this, THREAD_PRIORITY_NORMAL);

            if (m_incoming_thread == NULL)
            {
                Sleep(USER_TIMER_MINIMUM);
            }
        }
        while ((!truck_terminated) && (m_incoming_thread == NULL) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

        assert(m_incoming_thread != NULL);
        m_incoming_thread->m_bAutoDelete = TRUE;
    }
}


void CCTDlg::debug( loglevel_t lvl, TCHAR *format, ... )
{
    va_list arglist;
    int iLen;
    CTime ctm;
    CString log_time_tag;
    CHARFORMAT cfsrc, cfdst;
    ctm = CTime::GetCurrentTime();
    static TCHAR msg_buffer[INT16_MAX];
    log_time_tag = ctm.Format(_T("%B %d, %Y %H:%M:%S>"));
    va_start(arglist, format);
    vswprintf(msg_buffer, ((sizeof(msg_buffer) / sizeof(msg_buffer[0])) - 1), format, arglist);
    msg_buffer[((sizeof(msg_buffer) / sizeof(msg_buffer[0])) - 1)] = _T('\0');
    va_end(arglist);
    /* background log. */
    OutputDebugString(msg_buffer);

    if (lvl == LVL_B)
    {
        goto finish;
    }

    m_message.GetDefaultCharFormat(cfsrc);
    cfdst = cfsrc;

    switch (lvl)
    {
        case LVL_W:
            cfdst.dwMask |= CFM_COLOR;
            cfdst.dwEffects &= ~CFE_AUTOCOLOR;
            cfdst.crTextColor = RGB(0, 0, 255);
            break;

        case LVL_E:
            cfdst.dwMask |= CFM_COLOR;
            cfdst.dwEffects &= ~CFE_AUTOCOLOR;
            cfdst.crTextColor = RGB(255, 0, 0);
            break;

        case LVL_A:
            cfdst.dwMask |= CFM_COLOR;
            cfdst.dwEffects &= ~CFE_AUTOCOLOR;
            cfdst.crTextColor = RGB(0, 128, 0);
            break;

        case LVL_D:
        case LVL_RAW:
            break;
    }

    m_message.SetRedraw(FALSE);
    iLen = m_message.GetWindowTextLength();

    if (iLen >= (TRUCK_KILO * 0x10))
    {
        CString content;
        m_message.GetWindowText(content);
        m_message.SetWindowText(CString(content.GetBuffer() + (content.GetLength() / 2)));
    }

    if (lvl == LVL_RAW)
    {
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
        m_message.ReplaceSel(msg_buffer);
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
    }
    else
    {
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
        m_message.ReplaceSel(log_time_tag);
        m_message.SetSelectionCharFormat(cfdst);
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
        m_message.ReplaceSel(msg_buffer);
        m_message.SetSelectionCharFormat(cfsrc);
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
        m_message.ReplaceSel(_T("\n"));
        iLen = m_message.GetWindowTextLength();
        m_message.SetSel(iLen, iLen);
    }

    if (!m_avoid_update)
    {
        MessageWindowRedraw();
    }

finish:
    return;
}


void CCTDlg::MessageWindowRedraw()
{
    if (m_message.m_hWnd != NULL)
    {
        m_message.SendMessage(WM_VSCROLL, SB_BOTTOM, 0);
        m_message.SendMessage(WM_HSCROLL, SB_LEFT, 0);
        m_message.SetRedraw(TRUE);
        m_message.RedrawWindow(NULL, NULL, RDW_INVALIDATE | RDW_UPDATENOW | RDW_ERASE | RDW_FRAME | RDW_ALLCHILDREN);
    }
}


void CCTDlg::OnPaint()
{
    if (IsIconic())
    {
        CPaintDC dc(this); // device context for painting
        SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
        // Center icon in client rectangle
        int cxIcon = GetSystemMetrics(SM_CXICON);
        int cyIcon = GetSystemMetrics(SM_CYICON);
        CRect rect;
        GetClientRect(&rect);
        int x = (rect.Width() - cxIcon + 1) / 2;
        int y = (rect.Height() - cyIcon + 1) / 2;
        // Draw the icon
        dc.DrawIcon(x, y, m_hIcon);
    }
    else
    {
        CDialog::OnPaint();
    }
}


HCURSOR CCTDlg::OnQueryDragIcon()
{
    return static_cast<HCURSOR>(m_hIcon);
}


void CCTDlg::OnSize(UINT nType, int cx, int cy)
{
    const int frame_width = 180;
    const int logo_width = 160;
    RECT incoming_rect;
    RECT space_rect;
    RECT info_rect;
    RECT msg_rect;
    RECT logo_rect;
    RECT button_rect;
    CDialog::OnSize(nType, cx, cy);

    if (m_information_frame.m_hWnd != NULL)
    {
        m_space.GetWindowRect(&space_rect);
        ScreenToClient(&space_rect);
        m_incoming.GetWindowRect(&incoming_rect);
        ScreenToClient(&incoming_rect);
        //m_information_frame.GetWindowRect(&info_rect);
        //ScreenToClient(&info_rect);
        info_rect.left = 1;
        info_rect.top = 1;
        info_rect.right = frame_width;
        info_rect.bottom = space_rect.bottom + ((incoming_rect.top - info_rect.top) / 2);
        m_information_frame.MoveWindow(&info_rect);

        if (m_message.m_hWnd != NULL)
        {
            //m_message.GetWindowRect(&msg_rect);
            //ScreenToClient(&msg_rect);
            msg_rect.left = info_rect.right + info_rect.left + 1;
            msg_rect.top = 1;
            msg_rect.right = cx - 1;
            msg_rect.bottom = cy - 1;
            m_message.MoveWindow(&msg_rect);

            if (m_bottom_logo.m_hWnd != NULL)
            {
                m_pause.GetWindowRect(&button_rect);
                ScreenToClient(&button_rect);
                int btn_width = button_rect.right - button_rect.left;
                int btn_margin = (((info_rect.right - info_rect.left) - (btn_width * 2)) / 2) + 1;
                button_rect.left = btn_margin;
                button_rect.right = button_rect.left + btn_width;
                m_pause.MoveWindow(&button_rect);
                button_rect.left = button_rect.right;
                button_rect.right = button_rect.left + btn_width;
                m_resume.MoveWindow(&button_rect);
                m_bottom_logo.GetWindowRect(&logo_rect);
                ScreenToClient(&logo_rect);
                logo_rect.left = (info_rect.right - logo_width) / 2;
                logo_rect.right = info_rect.right - logo_rect.left;

                if ((cy - logo_width) < (button_rect.bottom))
                {
                    logo_rect.top = button_rect.bottom + 2;
                    logo_rect.bottom = logo_rect.top + logo_width;

                    if ((logo_rect.bottom) > (cy - 2))
                    {
                        logo_rect.bottom = (cy - 2);
                    }
                }
                else
                {
                    logo_rect.top = cy - logo_width - 2;
                    logo_rect.bottom = cy - 2;
                }

                m_bottom_logo.MoveWindow(&logo_rect);
            }
        }
    }
}


void CCTDlg::UpdateReport(string &report)
{
    CStringA line;
    EnterCriticalSection(&globallock);
    report.clear();
    wstring whostname(cct_hostname);
    string  hostname = ws2s(whostname);
    line.Format("HOSTNAME:%s\r\n", hostname.c_str());
    report += std::string(line.GetBuffer());
    line.Format("INCOMING:%llu\r\n", m_incoming_total);
    report += std::string(line.GetBuffer());
    line.Format("INIDLE:%llu\r\n", m_incoming_idle);
    report += std::string(line.GetBuffer());
    line.Format("OUTCOMING:%llu\r\n", m_outcoming_total);
    report += std::string(line.GetBuffer());
    line.Format("OUTIDLE:%llu\r\n", m_outcoming_idle);
    report += std::string(line.GetBuffer());
    line.Format("CLIENTS:%llu\r\n", m_active_clients);
    report += std::string(line.GetBuffer());
    line.Format("COLLECTORS:%llu\r\n", m_active_collectors);
    report += std::string(line.GetBuffer());
    line.Format("SPACE:%llu\r\n", m_free_space);
    report += std::string(line.GetBuffer());
    LeaveCriticalSection(&globallock);
}


void CCTDlg::OnTimer(UINT_PTR nIDEvent)
{
    BOOL empty;
    CString field;
    wstring ws;
    ULARGE_INTEGER FreeBytesAvailableToCaller;
    ULONGLONG delta;
    CDialog::OnTimer(nIDEvent);
    EnterCriticalSection(&datalock);
    empty = (black_clouds.empty() && white_clouds.empty() && colorful_clouds.empty());
    LeaveCriticalSection(&datalock);
    EnterCriticalSection(&loglock);

    if (!trace_logs.empty())
    {
        m_avoid_update = TRUE;

        for (string item : trace_logs)
        {
            ws = s2ws(item);
            debug(LVL_D, (TCHAR *)ws.c_str());
        }

        m_avoid_update = FALSE;
        MessageWindowRedraw();
        trace_logs.clear();
        trace_logs.shrink_to_fit();
    }

    LeaveCriticalSection(&loglock);

    if ((!m_idle_notified) && (empty) && (m_incoming_thread == NULL))
    {
        if (m_idle_counter == 0ULL)
        {
            m_idle_counter++;
        }
        else
        {
            m_idle_counter = 0ULL;
            m_idle_notified = TRUE;
            debug(LVL_W, _T("MQM Truck %s is safe to close"), cct_hostname);
        }
    }
    else
    {
        m_idle_counter = 0ULL;
    }

    EnterCriticalSection(&globallock);

    if (GetDiskFreeSpaceEx(cct_temppath, &FreeBytesAvailableToCaller, NULL, NULL))
    {
        m_free_space = FreeBytesAvailableToCaller.QuadPart;
    }

    field = FormatSpaceSize(m_incoming_total);
    m_incoming.SetWindowText(field);
    delta = GetTickCount64() - m_incoming_idle;
    field = FormatDateTime(delta);
    m_inidle.SetWindowText(field);
    field = FormatSpaceSize(m_outcoming_total);
    m_outcoming.SetWindowText(field);
    delta = GetTickCount64() - m_outcoming_idle;
    field = FormatDateTime(delta);
    m_outidle.SetWindowText(field);
    field.Format(_T("%llu"), m_active_clients);
    m_clients.SetWindowText(field);
    field.Format(_T("%llu"), m_active_collectors);
    m_collectors.SetWindowText(field);
    field = FormatSpaceSize(m_free_space);
    m_space.SetWindowText(field);
    LeaveCriticalSection(&globallock);
    UpdateReport(m_report);
}


void CCTDlg::InitializeWinsock2()
{
    WORD wVersionRequested;
    WSADATA wsaData;
    int err;
    /* Use the MAKEWORD(lowbyte, highbyte) macro declared in Windef.h */
    wVersionRequested = MAKEWORD(2, 2);
    err = WSAStartup(wVersionRequested, &wsaData);

    if (err != 0)
    {
        debug( LVL_W, _T("WSAStartup failed with: %d"), WSAGetLastError());
    }

    if ((LOBYTE(wsaData.wVersion) != 2) || (HIBYTE(wsaData.wVersion) != 2))
    {
        debug( LVL_D, _T("WinSock version is %d.%d "), LOBYTE(wsaData.wVersion), HIBYTE(wsaData.wVersion));
    }
}


void CCTDlg::OnDestroy()
{
    truck_terminated = TRUE;

    if (m_incoming_thread != NULL)
    {
        ::WaitForSingleObject(m_incoming_thread->m_hThread, INFINITE);
        m_incoming_thread = NULL;
    }

    if (m_outcoming_thread != NULL)
    {
        ::WaitForSingleObject(m_outcoming_thread->m_hThread, INFINITE);
        m_outcoming_thread = NULL;
    }

    if (m_control_thread != NULL)
    {
        ::WaitForSingleObject(m_control_thread->m_hThread, INFINITE);
        m_control_thread = NULL;
    }

    DeleteCriticalSection(&loglock);
    DeleteCriticalSection(&datalock);
    DeleteCriticalSection(&globallock);
    CDialog::OnDestroy();
    lmdns_exit();
    WSACleanup();
}


BOOL CCTDlg::PreTranslateMessage(MSG *pMsg)
{
    if ( pMsg->message == WM_KEYDOWN && ( pMsg->wParam == VK_ESCAPE || pMsg->wParam == VK_RETURN || pMsg->wParam == VK_CANCEL ))
    {
        return TRUE;
    }

    return CDialog::PreTranslateMessage(pMsg);
}


AFX_THREADPROC CCTDlg::DataIncomingThread(LPVOID pParam)
{
    BOOL paused = FALSE;
    int id = 0;
    int ret;
    fd_set set;
    timeval tv;
    DWORD dwThreadId = 1;
    HANDLE h = INVALID_HANDLE_VALUE;
    SOCKET server = INVALID_SOCKET;
    CCTDlg *pDlg = (CCTDlg *)pParam;
    assert(pDlg != NULL);
    server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    sockaddr_in addr_server;
    memset(&addr_server, 0, sizeof(sockaddr_in));
    addr_server.sin_family = AF_INET;
    addr_server.sin_port = htons(TRUCK_SERVER_PORT);
    addr_server.sin_addr.s_addr = htonl(INADDR_ANY);

    //bind server
    if (bind(server, (sockaddr *)&addr_server, sizeof(sockaddr)) == SOCKET_ERROR)
    {
        mt_debug("Failed to bind, WSAGetLastError()=%d", WSAGetLastError());
    }

    //listen client
    if (listen(server, SOMAXCONN) == SOCKET_ERROR)
    {
        mt_debug("Failed to listen, WSAGetLastError()=%d", WSAGetLastError());
    }

    tv.tv_sec = 0;
    tv.tv_usec = USER_TIMER_MINIMUM * 1000L;

    while (!truck_terminated)
    {
        EnterCriticalSection(&globallock);
        paused = truck_paused;
        LeaveCriticalSection(&globallock);

        if (paused)
        {
            break;
        }

        do
        {
            EnterCriticalSection(&globallock);
            paused = truck_paused;
            LeaveCriticalSection(&globallock);
            FD_ZERO(&set);
            FD_SET(server, &set);
            ret = select(server, &set, NULL, NULL, &tv);

            if (ret > 0)
            {
                break;
            }
        }
        while ((!truck_terminated) && (!paused) && (ret != SOCKET_ERROR));

        if (ret == SOCKET_ERROR)
        {
            mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
            break;
        }
        else if ((truck_terminated) || (paused))
        {
            break;
        }

        pCLIENT pc = (pCLIENT)LocalAlloc(LMEM_ZEROINIT, sizeof(CLIENT));
        assert(pc != NULL);
        pc->sa_len = sizeof(sockaddr_in);
        pc->sock = ::accept(server, (SOCKADDR *)&pc->sa, &pc->sa_len);

        if (INVALID_SOCKET == pc->sock)
        {
            LocalFree(pc);
            continue;
        }
        else
        {
            id++;
            pc->id = id;
            pc->pDlg = pDlg;
        }

        do
        {
            h = CreateThread(NULL, 0, CCTDlg::DataIncomingClientThread, (LPVOID)pc, 0, &dwThreadId);

            if (h == NULL)
            {
                Sleep(USER_TIMER_MINIMUM);
            }
        }
        while ((h == NULL) && (!truck_terminated));

        if ((INVALID_HANDLE_VALUE != h) && (NULL != h))
        {
            CloseHandle(h);
        }
        else
        {
            LocalFree(pc);
        }
    }

    closesocket(server);

    if (paused)
    {
        mt_debug("User request pause");
    }

    return 0;
}


DWORD WINAPI CCTDlg::DataIncomingClientThread(LPVOID lpPar)
{
    BOOL opened = FALSE;
    UINT immediate_value = 0;
    ULONGLONG unique_id = 0ULL;
    TCHAR filename[MAX_PATH];
    TCHAR immediate[MAX_PATH];
    CString header;
    string vidata_servers;
    BOOL log_ota;
    CLIENT *pc = (CLIENT *)lpPar;

    if (pc != NULL)
    {
        CFile f;
        EnterCriticalSection(&globallock);
        assert(pc->pDlg != NULL);
        pc->pDlg->m_active_clients++;
        vidata_servers = pc->pDlg->m_vidata_servers;
        log_ota = pc->pDlg->m_log_ota;
        immediate_value = GetTempFileName(pc->pDlg->cct_temppath, _T("Truck"), 0, immediate);
        LeaveCriticalSection(&globallock);

        if (immediate_value != 0)
        {
            opened = f.Open(immediate, MQM_BINARY_WRITE);

            if (opened)
            {
                f.SeekToBegin();
            }
        }

        if ((!truck_terminated) && (pc->sock != INVALID_SOCKET) && (opened))
        {
            int nRecv;
            int ret;
            FD_SET set;
            timeval tv;
            BOOL eos;
            SOCKET sock = pc->sock;
            ULONGLONG anchor = GetTickCount64();
            string datain;
            CStringW temppath;
            LPSTR buffer = (LPSTR)LocalAlloc(LMEM_ZEROINIT, (SIZE_T)TRUCK_REQUEST_MAX);
            LPSTR response = (LPSTR)LocalAlloc(LMEM_ZEROINIT, (SIZE_T)TRUCK_RESPONSE_MAX);
            assert(response != NULL);
            assert(buffer != NULL);
            tv.tv_sec = 0;
            tv.tv_usec = USER_TIMER_MINIMUM * 1000L;
            temppath.Format(_T("%s%02X\\"), pc->pDlg->cct_temppath, (pc->id & 0xFF));

            do
            {
                eos = FALSE;

                do
                {
                    FD_ZERO(&set);
                    FD_SET(sock, &set);
                    ret = select(sock, &set, NULL, NULL, &tv);

                    if (ret > 0)
                    {
                        break;
                    }
                    else if (ret == SOCKET_ERROR)
                    {
                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                    }
                }
                while ((!truck_terminated) && (ret != SOCKET_ERROR) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                if (ret > 0)
                {
                    nRecv = ::recv(sock, buffer, (TRUCK_REQUEST_MAX - 1), 0);

                    if (nRecv > 0)
                    {
                        buffer[nRecv] = '\0';
                        eos = (buffer[nRecv - 1] == '\0');

                        if (datain.length() < TRUCK_REQUEST_MAX)
                        {
                            datain += std::string(buffer);
                        }

                        f.Write(buffer, strlen(buffer));
                        anchor = GetTickCount64();
                    }

                    if (datain.length() >= (sizeof(STAT_PUSH) - sizeof(CHAR)))
                    {
                        const char *buf = datain.c_str();

                        if ((buf == NULL) || (buf[0] != STAT_PUSH[0]) || (buf[1] != STAT_PUSH[1]) || (buf[2] != STAT_PUSH[2]))
                        {
                            nRecv = 0;
                            eos = FALSE;
                        }
                    }
                    else if (eos)
                    {
                        nRecv = 0;
                        eos = FALSE;
                    }
                }
                else
                {
                    nRecv = 0;
                }
            }
            while ((!truck_terminated) && (nRecv > 0) && (!eos) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

            if ((nRecv > 0) && (eos))
            {
                UINT length = (UINT)f.GetLength();

                do
                {
                    FD_ZERO(&set);
                    FD_SET(sock, &set);
                    ret = select(sock, NULL, &set, NULL, &tv);

                    if (ret > 0)
                    {
                        break;
                    }
                    else if (ret == SOCKET_ERROR)
                    {
                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                    }
                }
                while ((!truck_terminated) && (ret != SOCKET_ERROR) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                if (ret > 0)
                {
                    CStringA ip;
                    CStringA records;
                    string hostname = GetFieldContent(datain, "HOSTNAME");
                    string extra;
                    CStringA hostA(hostname.c_str());
                    ip.Format("%u.%u.%u.%u"
                              , pc->sa.sin_addr.S_un.S_un_b.s_b1
                              , pc->sa.sin_addr.S_un.S_un_b.s_b2
                              , pc->sa.sin_addr.S_un.S_un_b.s_b3
                              , pc->sa.sin_addr.S_un.S_un_b.s_b4
                             );
                    EnterCriticalSection(&globallock);
                    lmdns_add(ip, hostA);
                    lmdns_export(records);
                    LeaveCriticalSection(&globallock);

                    /* Truck => MQM client */
                    /* Send response back with DNS records to MQM client */
                    if (!records.IsEmpty())
                    {
                        CStringA dns;
                        string encoded = base64_encode((const unsigned char *)records.GetBuffer(), records.GetLength());
                        dns.Format("\r\nDNS:%s\r\n", encoded.c_str());
                        extra += string(dns.GetBuffer());
                    }

                    if (!vidata_servers.empty())
                    {
                        CStringA vidata;
                        string encoded = base64_encode((const unsigned char *)vidata_servers.c_str(), vidata_servers.length());
                        vidata.Format("\r\nVIDATA:%s\r\n", encoded.c_str());
                        extra += string(vidata.GetBuffer());
                    }

                    if (log_ota)
                    {
                        extra += string("\r\nLOGOTA:TRUE\r\n");
                    }
                    else
                    {
                        extra += string("\r\nLOGOTA:FALSE\r\n");
                    }

                    if (!extra.empty())
                    {
                        sprintf(response, HTTP_RESPONSE_SUCCESS"\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>\r\n%s", pc->id, (int)length, extra.c_str());
                    }
                    else
                    {
                        sprintf(response, HTTP_RESPONSE_SUCCESS"\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>", pc->id, (int)length);
                    }

                    ::send(sock, response, strlen(response) + sizeof(CHAR), 0);
                }

                closesocket(sock);
                unique_id++;
                header = GetItemPayloadType(datain);

                if (!header.IsEmpty())
                {
                    if (GetUniqueTempFileName(temppath.GetBuffer(), header.GetBuffer(), unique_id, filename))
                    {
                        f.Flush();

                        if (CopyFile(immediate, filename, FALSE))
                        {
                            BOOL valid_type = FALSE;
                            EnterCriticalSection(&datalock);

                            if (header == CString(_T(QVD_PUSH)))
                            {
                                valid_type = TRUE;
                                black_clouds.push_back(filename);
                            }
                            else if (header == CString(_T(JSON_PUSH)))
                            {
                                valid_type = TRUE;
                                white_clouds.push_back(filename);
                            }
                            else if (header == CString(_T(EMAIL_PUSH)))
                            {
                                valid_type = TRUE;
                                colorful_clouds.push_back(filename);
                            }
                            else
                            {
                                SetFileAttributes(filename, FILE_ATTRIBUTE_NORMAL);
                                DeleteFile(filename);
                            }

                            LeaveCriticalSection(&datalock);

                            if (valid_type)
                            {
                                EnterCriticalSection(&globallock);
                                pc->pDlg->m_incoming_total += length;
                                pc->pDlg->m_incoming_idle = GetTickCount64();
                                LeaveCriticalSection(&globallock);

                                if (!datain.empty())
                                {
                                    string hostname = GetFieldContent(datain, "HOSTNAME");

                                    if (!hostname.empty())
                                    {
                                        mt_debug("Incoming %d bytes from %s", length, hostname.c_str());
                                    }
                                }
                            }
                        }
                    }
                }
            }
            else
            {
                closesocket(sock);
            }

            LocalFree(response);
            LocalFree(buffer);
        }

        if (immediate_value != 0)
        {
            if (opened)
            {
                f.Close();
            }

            SetFileAttributes(immediate, FILE_ATTRIBUTE_NORMAL);
            DeleteFile(immediate);
        }

        EnterCriticalSection(&globallock);
        pc->pDlg->m_active_clients--;
        LeaveCriticalSection(&globallock);
        LocalFree(pc);
    }

    return 0;
}


AFX_THREADPROC CCTDlg::DataOutcomingThread(LPVOID pParam)
{
    int id = 0;
    int ret;
    fd_set set;
    timeval tv;
    DWORD dwThreadId = 1;
    HANDLE h = INVALID_HANDLE_VALUE;
    SOCKET server = INVALID_SOCKET;
    CCTDlg *pDlg = (CCTDlg *)pParam;
    assert(pDlg != NULL);
    server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    sockaddr_in addr_server;
    memset(&addr_server, 0, sizeof(sockaddr_in));
    addr_server.sin_family = AF_INET;
    addr_server.sin_port = htons(TRUCK_SERVER_PORT + 1);
    addr_server.sin_addr.s_addr = htonl(INADDR_ANY);

    //bind server
    if (bind(server, (sockaddr *)&addr_server, sizeof(sockaddr)) == SOCKET_ERROR)
    {
        mt_debug("Failed to bind, WSAGetLastError()=%d", WSAGetLastError());
    }

    //listen client
    if (listen(server, SOMAXCONN) == SOCKET_ERROR)
    {
        mt_debug("Failed to listen, WSAGetLastError()=%d", WSAGetLastError());
    }

    tv.tv_sec = 0;
    tv.tv_usec = USER_TIMER_MINIMUM * 1000L;

    while (!truck_terminated)
    {
        do
        {
            FD_ZERO(&set);
            FD_SET(server, &set);
            ret = select(server, &set, NULL, NULL, &tv);

            if (ret > 0)
            {
                break;
            }
        }
        while ((!truck_terminated) && (ret != SOCKET_ERROR));

        if ((truck_terminated) || (ret == SOCKET_ERROR))
        {
            mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
            break;
        }

        pCLIENT pc = (pCLIENT)LocalAlloc(LMEM_ZEROINIT, sizeof(CLIENT));
        assert(pc != NULL);
        pc->sa_len = sizeof(sockaddr_in);
        pc->sock = ::accept(server, (SOCKADDR *)&pc->sa, &pc->sa_len);

        if (INVALID_SOCKET == pc->sock)
        {
            LocalFree(pc);
            continue;
        }
        else
        {
            id++;
            pc->id = id;
            pc->pDlg = pDlg;
        }

        do
        {
            h = CreateThread(NULL, 0, CCTDlg::DataOutcomingClientThread, (LPVOID)pc, 0, &dwThreadId);

            if (h == NULL)
            {
                Sleep(USER_TIMER_MINIMUM);
            }
        }
        while ((h == NULL) && (!truck_terminated));

        if ((INVALID_HANDLE_VALUE != h) && (NULL != h))
        {
            CloseHandle(h);
        }
        else
        {
            LocalFree(pc);
        }
    }

    closesocket(server);
    return 0;
}


DWORD WINAPI CCTDlg::DataOutcomingClientThread(LPVOID lpPar)
{
    string vidata_servers;
    BOOL log_ota;
    CLIENT *pc = (CLIENT *)lpPar;

    if (pc != NULL)
    {
        EnterCriticalSection(&globallock);
        assert(pc->pDlg != NULL);
        pc->pDlg->m_active_collectors++;
        vidata_servers = pc->pDlg->m_vidata_servers;
        log_ota = pc->pDlg->m_log_ota;
        LeaveCriticalSection(&globallock);

        if ((!truck_terminated) && (pc->sock != INVALID_SOCKET))
        {
            int nRecv;
            int ret;
            FD_SET set;
            timeval tv;
            BOOL eos;
            SOCKET sock = pc->sock;
            ULONGLONG anchor = GetTickCount64();
            string request;
            LPSTR buffer = (LPSTR)LocalAlloc(LMEM_ZEROINIT, (SIZE_T)TRUCK_REQUEST_MAX);
            assert(buffer != NULL);
            tv.tv_sec = 0;
            tv.tv_usec = USER_TIMER_MINIMUM * 1000L;

            do
            {
                eos = FALSE;

                do
                {
                    FD_ZERO(&set);
                    FD_SET(sock, &set);
                    ret = select(sock, &set, NULL, NULL, &tv);

                    if (ret > 0)
                    {
                        break;
                    }
                    else if (ret == SOCKET_ERROR)
                    {
                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                    }
                }
                while ((!truck_terminated) && (ret != SOCKET_ERROR) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                if (ret > 0)
                {
                    nRecv = ::recv(sock, buffer, (TRUCK_REQUEST_MAX - 1), 0);

                    if (nRecv > 0)
                    {
                        if (request.length() < (TRUCK_REQUEST_MAX * TRUCK_KILO))
                        {
                            buffer[nRecv] = '\0';
                            eos = (buffer[nRecv - 1] == '\0');
                            request += std::string(buffer);
                            anchor = GetTickCount64();
                        }
                        else
                        {
                            nRecv = 0;
                            eos = FALSE;
                        }
                    }

                    if (request.length() >= sizeof(STAT_PUSH) - sizeof(CHAR))
                    {
                        const char *buf = request.c_str();

                        if ((buf == NULL) || (buf[0] != STAT_PUSH[0]) || (buf[1] != STAT_PUSH[1]) || (buf[2] != STAT_PUSH[2]))
                        {
                            nRecv = 0;
                            eos = FALSE;
                        }
                    }
                    else if (eos)
                    {
                        nRecv = 0;
                        eos = FALSE;
                    }
                }
                else
                {
                    nRecv = 0;
                }
            }
            while ((!truck_terminated) && (nRecv > 0) && (!eos) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

            if ((nRecv > 0) && (eos))
            {
                do
                {
                    FD_ZERO(&set);
                    FD_SET(sock, &set);
                    ret = select(sock, NULL, &set, NULL, &tv);

                    if (ret > 0)
                    {
                        break;
                    }
                    else if (ret == SOCKET_ERROR)
                    {
                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                    }
                }
                while ((!truck_terminated) && (ret != SOCKET_ERROR) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                if (ret > 0)
                {
                    BOOL black_empty;
                    BOOL white_empty;
                    BOOL colorful_empty;
                    wstring filename;
                    EnterCriticalSection(&datalock);
                    black_empty = black_clouds.empty();
                    white_empty = white_clouds.empty();
                    colorful_empty = colorful_clouds.empty();
                    LeaveCriticalSection(&datalock);

                    if (request.substr(0, sizeof(STAT_PUSH) - sizeof(CHAR)) == std::string(STAT_PUSH))
                    {
                        string host = GetFieldContent(request, "HOSTNAME");

                        if (!host.empty())
                        {
                            CStringA response;
                            CStringA hostA(host.c_str());
                            int size;
                            int sent;
                            string content;
                            CStringA ip;
                            CStringA surfix;
                            ip.Format("%u.%u.%u.%u"
                                      , pc->sa.sin_addr.S_un.S_un_b.s_b1
                                      , pc->sa.sin_addr.S_un.S_un_b.s_b2
                                      , pc->sa.sin_addr.S_un.S_un_b.s_b3
                                      , pc->sa.sin_addr.S_un.S_un_b.s_b4
                                     );
                            surfix.Format("IP:%s\r\nHEARTBEAT:%llu\r\n", ip.GetBuffer(), GetTickCount64());
                            content = request + std::string(surfix.GetBuffer());
                            CStringA key;
                            CStringA records;
                            key.Format("\r\nIP:%s\r\n", ip.GetBuffer());
                            EnterCriticalSection(&globallock);
                            BOOL found = FALSE;
                            string item;

                            for (size_t i = 0; i < truck_list.size(); i++)
                            {
                                item = truck_list.at(i);

                                if (item.find(key.GetBuffer()) != std::string::npos)
                                {
                                    found = TRUE;
                                    truck_list[i] = content;
                                    break;
                                }
                            }

                            if (!found)
                            {
                                truck_list.push_back(content);
                            }

                            lmdns_add(ip, hostA);
                            lmdns_export(records);
                            LeaveCriticalSection(&globallock);
                            string encoded_records = base64_encode((const unsigned char *)records.GetBuffer(), records.GetLength());

                            if (!found)
                            {
                                mt_debug("Auxiliary truck %s (%s) registered", host.c_str(), ip.GetBuffer());

                                if (!encoded_records.empty())
                                {
                                    response.Format(HTTP_RESPONSE_SUCCESS"\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>\r\nDNS:%s\r\n", pc->id, (int)request.length(), encoded_records.c_str());
                                }
                                else
                                {
                                    response.Format(HTTP_RESPONSE_SUCCESS"\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>", pc->id, (int)request.length());
                                }

                                if (!vidata_servers.empty())
                                {
                                    CStringA vidata;
                                    string encoded = base64_encode((const unsigned char *)vidata_servers.c_str(), vidata_servers.length());
                                    vidata.Format("\r\nVIDATA:%s\r\n", encoded.c_str());
                                    response += vidata;
                                }

                                if (log_ota)
                                {
                                    response += CStringA("\r\nLOGOTA:TRUE\r\n");
                                }
                                else
                                {
                                    response += CStringA("\r\nLOGOTA:FALSE\r\n");
                                }

                                size = strlen(response) + sizeof(CHAR);
                                sent = ::send(sock, response, size, 0);
                            }
                            else
                            {
                                if (!encoded_records.empty())
                                {
                                    response.Format("HTTP/1.1 302 Found\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>\r\nDNS:%s\r\n", pc->id, (int)request.length(), encoded_records.c_str());
                                }
                                else
                                {
                                    response.Format("HTTP/1.1 302 Found\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>", pc->id, (int)request.length());
                                }

                                if (!vidata_servers.empty())
                                {
                                    CStringA vidata;
                                    string encoded = base64_encode((const unsigned char *)vidata_servers.c_str(), vidata_servers.length());
                                    vidata.Format("\r\nVIDATA:%s\r\n", encoded.c_str());
                                    response += vidata;
                                }

                                if (log_ota)
                                {
                                    response += CStringA("\r\nLOGOTA:TRUE\r\n");
                                }
                                else
                                {
                                    response += CStringA("\r\nLOGOTA:FALSE\r\n");
                                }

                                size = strlen(response) + sizeof(CHAR);
                                sent = ::send(sock, response, size, 0);
                            }
                        }
                        else
                        {
                            CStringA response;
                            response.Format("HTTP/1.1 400 Bad Request\r\n\r\n<html><body><h1>id=%d,length=%d</h1></body></html>", pc->id, (int)request.length());

                            if (!vidata_servers.empty())
                            {
                                CStringA vidata;
                                string encoded = base64_encode((const unsigned char *)vidata_servers.c_str(), vidata_servers.length());
                                vidata.Format("\r\nVIDATA:%s\r\n", encoded.c_str());
                                response += vidata;
                            }

                            if (log_ota)
                            {
                                response += CStringA("\r\nLOGOTA:TRUE\r\n");
                            }
                            else
                            {
                                response += CStringA("\r\nLOGOTA:FALSE\r\n");
                            }

                            int size = strlen(response) + sizeof(CHAR);
                            ::send(sock, response, size, 0);
                        }
                    }
                    else if (request.substr(0, sizeof(STAT_POLL) - sizeof(CHAR)) == std::string(STAT_POLL))
                    {
                        BOOL primary;
                        CStringA req;
                        CStringA host;
                        string response;
                        string ip;
                        string cur_report;
                        string hostname;
                        EnterCriticalSection(&globallock);
                        primary = pc->pDlg->m_primary;
                        cur_report = pc->pDlg->m_report;
                        host = CStringA(pc->pDlg->cct_hostname);
                        LeaveCriticalSection(&globallock);
                        ip = ResolveName(host.GetBuffer());
                        hostname = GetFieldContent(request, "HOSTNAME");

                        if (!ip.empty())
                        {
                            req.Format("%s\r\n", STAT_POLL);
                            cur_report = std::string(req.GetBuffer()) + cur_report;
                            req.Format("IP:%s\r\nHEARTBEAT:%llu\r\n\r\n", ip.c_str(), GetTickCount64());
                            response = cur_report + std::string(req.GetBuffer());

                            if (primary)
                            {
                                EnterCriticalSection(&globallock);

                                for (auto item : truck_list)
                                {
                                    string beat = GetFieldContent(item, "HEARTBEAT");

                                    if (!beat.empty())
                                    {
                                        ULONGLONG last_beat = strtoull(beat.c_str(), NULL, 10);

                                        if (last_beat != 0)
                                        {
                                            if ((GetTickCount64() - last_beat) < (TRUCK_TIMEOUT * 1000ULL))
                                            {
                                                response += item + std::string("\r\n");
                                            }
                                        }
                                    }
                                }

                                LeaveCriticalSection(&globallock);
                            }

                            CStringA ipa;
                            CStringA hosta(hostname.c_str());
                            CStringA records;
                            EnterCriticalSection(&globallock);
                            ipa.Format("%u.%u.%u.%u"
                                       , pc->sa.sin_addr.S_un.S_un_b.s_b1
                                       , pc->sa.sin_addr.S_un.S_un_b.s_b2
                                       , pc->sa.sin_addr.S_un.S_un_b.s_b3
                                       , pc->sa.sin_addr.S_un.S_un_b.s_b4
                                      );
                            lmdns_add(ipa, hosta);
                            lmdns_export(records);
                            LeaveCriticalSection(&globallock);

                            if (!records.IsEmpty())
                            {
                                CStringA ns;
                                string encoded_records = base64_encode((const unsigned char *)records.GetBuffer(), records.GetLength());
                                ns.Format("\r\nDNS:%s\r\n", encoded_records.c_str());
                                response += string(ns.GetBuffer());
                            }

                            if (!vidata_servers.empty())
                            {
                                CStringA vidata;
                                string encoded = base64_encode((const unsigned char *)vidata_servers.c_str(), vidata_servers.length());
                                vidata.Format("\r\nVIDATA:%s\r\n", encoded.c_str());
                                response += string(vidata.GetBuffer());
                            }

                            if (log_ota)
                            {
                                response += string("\r\nLOGOTA:TRUE\r\n");
                            }
                            else
                            {
                                response += string("\r\nLOGOTA:FALSE\r\n");
                            }

                            int size = response.length() + sizeof(CHAR);
                            ::send(sock, response.c_str(), size, 0);

                            if (!hostname.empty())
                            {
                                mt_debug("%s polling available trucks", hostname.c_str());
                            }
                        }
                    }
                    else if ((!black_empty) && (request.substr(0, sizeof(QVD_POLL) - sizeof(CHAR)) == std::string(QVD_POLL)))
                    {
                        EnterCriticalSection(&datalock);

                        if (!black_clouds.empty())
                        {
                            filename = black_clouds[0];
                            black_clouds.erase(black_clouds.begin());
                            black_clouds.shrink_to_fit();
                        }
                        else
                        {
                            filename.clear();
                            filename.shrink_to_fit();
                        }

                        LeaveCriticalSection(&datalock);

                        if (!filename.empty())
                        {
                            CFile fr;
                            BOOL processed = FALSE;

                            if (fr.Open(filename.c_str(), MQM_BINARY_READ))
                            {
                                UINT length;
                                fr.SeekToEnd();
                                length = (UINT)fr.GetLength();
                                fr.SeekToBegin();

                                if (length > 0)
                                {
                                    LPSTR data = (LPSTR)LocalAlloc(LMEM_ZEROINIT, TRUCK_REQUEST_MAX + sizeof(CHAR));

                                    if (data != NULL)
                                    {
                                        UINT readout;
                                        UINT left = length;
                                        UINT send;
                                        UINT sent = 0U;

                                        do
                                        {
                                            if (left > TRUCK_REQUEST_MAX)
                                            {
                                                readout = fr.Read(data, TRUCK_REQUEST_MAX);
                                                assert(readout == TRUCK_REQUEST_MAX);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, TRUCK_REQUEST_MAX, 0);

                                                if (send != TRUCK_REQUEST_MAX)
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left -= TRUCK_REQUEST_MAX;
                                                }
                                            }
                                            else
                                            {
                                                readout = fr.Read(data, left);
                                                assert(readout == left);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, left + sizeof(CHAR), 0);

                                                if (send != (left + sizeof(CHAR)))
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left = 0;
                                                }
                                            }

                                            sent += send;
                                        }
                                        while (sent < length);

                                        if ((left == 0) && (sent == (length + sizeof(CHAR))))
                                        {
                                            EnterCriticalSection(&globallock);
                                            pc->pDlg->m_outcoming_total += length;
                                            pc->pDlg->m_outcoming_idle = GetTickCount64();
                                            LeaveCriticalSection(&globallock);
                                            processed = TRUE;
                                        }
                                        else
                                        {
                                            volatile static BOOL ignore = FALSE;

                                            if (!ignore)
                                            {
                                                EnterCriticalSection(&datalock);
                                                black_clouds.insert(black_clouds.begin(), filename);
                                                LeaveCriticalSection(&datalock);
                                            }
                                        }

                                        LocalFree(data);
                                    }
                                    else
                                    {
                                        EnterCriticalSection(&datalock);
                                        black_clouds.insert(black_clouds.begin(), filename);
                                        LeaveCriticalSection(&datalock);
                                    }
                                }
                                else
                                {
                                    processed = TRUE;
                                }

                                fr.Close();
                            }
                            else
                            {
                                processed = TRUE;
                            }

                            /* clean up temp file when finish */
                            if (processed)
                            {
                                SetFileAttributes(filename.c_str(), FILE_ATTRIBUTE_NORMAL);
                                DeleteFile(filename.c_str());
                            }
                        }
                    }
                    else if ((!white_empty) && (request.substr(0, sizeof(JSON_POLL) - sizeof(CHAR)) == std::string(JSON_POLL)))
                    {
                        EnterCriticalSection(&datalock);

                        if (!white_clouds.empty())
                        {
                            filename = white_clouds[0];
                            white_clouds.erase(white_clouds.begin());
                            white_clouds.shrink_to_fit();
                        }
                        else
                        {
                            filename.clear();
                            filename.shrink_to_fit();
                        }

                        LeaveCriticalSection(&datalock);

                        if (!filename.empty())
                        {
                            CFile fr;
                            BOOL processed = FALSE;

                            if (fr.Open(filename.c_str(), MQM_BINARY_READ))
                            {
                                UINT length;
                                fr.SeekToEnd();
                                length = (UINT)fr.GetLength();
                                fr.SeekToBegin();

                                if (length > 0)
                                {
                                    LPSTR data = (LPSTR)LocalAlloc(LMEM_ZEROINIT, TRUCK_REQUEST_MAX + sizeof(CHAR));

                                    if (data != NULL)
                                    {
                                        UINT readout;
                                        UINT left = length;
                                        UINT send;
                                        UINT sent = 0U;

                                        do
                                        {
                                            if (left > TRUCK_REQUEST_MAX)
                                            {
                                                readout = fr.Read(data, TRUCK_REQUEST_MAX);
                                                assert(readout == TRUCK_REQUEST_MAX);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, TRUCK_REQUEST_MAX, 0);

                                                if (send != TRUCK_REQUEST_MAX)
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left -= TRUCK_REQUEST_MAX;
                                                }
                                            }
                                            else
                                            {
                                                readout = fr.Read(data, left);
                                                assert(readout == left);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, left + sizeof(CHAR), 0);

                                                if (send != (left + sizeof(CHAR)))
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left = 0;
                                                }
                                            }

                                            sent += send;
                                        }
                                        while (sent < length);

                                        if ((left == 0) && (sent == (length + sizeof(CHAR))))
                                        {
                                            EnterCriticalSection(&globallock);
                                            pc->pDlg->m_outcoming_total += length;
                                            pc->pDlg->m_outcoming_idle = GetTickCount64();
                                            LeaveCriticalSection(&globallock);
                                            processed = TRUE;
                                        }
                                        else
                                        {
                                            volatile static BOOL ignore = FALSE;

                                            if (!ignore)
                                            {
                                                EnterCriticalSection(&datalock);
                                                white_clouds.insert(white_clouds.begin(), filename);
                                                LeaveCriticalSection(&datalock);
                                            }
                                        }

                                        LocalFree(data);
                                    }
                                    else
                                    {
                                        EnterCriticalSection(&datalock);
                                        white_clouds.insert(white_clouds.begin(), filename);
                                        LeaveCriticalSection(&datalock);
                                    }
                                }
                                else
                                {
                                    processed = TRUE;
                                }

                                fr.Close();
                            }
                            else
                            {
                                processed = TRUE;
                            }

                            /* clean up temp file when finish */
                            if (processed)
                            {
                                SetFileAttributes(filename.c_str(), FILE_ATTRIBUTE_NORMAL);
                                DeleteFile(filename.c_str());
                            }
                        }
                    }
                    else if ((!colorful_empty) && (request.substr(0, sizeof(EMAIL_POLL) - sizeof(CHAR)) == std::string(EMAIL_POLL)))
                    {
                        EnterCriticalSection(&datalock);

                        if (!colorful_clouds.empty())
                        {
                            filename = colorful_clouds[0];
                            colorful_clouds.erase(colorful_clouds.begin());
                            colorful_clouds.shrink_to_fit();
                        }
                        else
                        {
                            filename.clear();
                            filename.shrink_to_fit();
                        }

                        LeaveCriticalSection(&datalock);

                        if (!filename.empty())
                        {
                            CFile fr;
                            BOOL processed = FALSE;

                            if (fr.Open(filename.c_str(), MQM_BINARY_READ))
                            {
                                UINT length;
                                fr.SeekToEnd();
                                length = (UINT)fr.GetLength();
                                fr.SeekToBegin();

                                if (length > 0)
                                {
                                    LPSTR data = (LPSTR)LocalAlloc(LMEM_ZEROINIT, TRUCK_REQUEST_MAX + sizeof(CHAR));

                                    if (data != NULL)
                                    {
                                        UINT readout;
                                        UINT left = length;
                                        UINT send;
                                        UINT sent = 0U;

                                        do
                                        {
                                            if (left > TRUCK_REQUEST_MAX)
                                            {
                                                readout = fr.Read(data, TRUCK_REQUEST_MAX);
                                                assert(readout == TRUCK_REQUEST_MAX);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, TRUCK_REQUEST_MAX, 0);

                                                if (send != TRUCK_REQUEST_MAX)
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left -= TRUCK_REQUEST_MAX;
                                                }
                                            }
                                            else
                                            {
                                                readout = fr.Read(data, left);
                                                assert(readout == left);
                                                data[readout] = '\0';
                                                send = ::send(sock, data, left + sizeof(CHAR), 0);

                                                if (send != (left + sizeof(CHAR)))
                                                {
                                                    break;
                                                }
                                                else
                                                {
                                                    left = 0;
                                                }
                                            }

                                            sent += send;
                                        }
                                        while (sent < length);

                                        if ((left == 0) && (sent == (length + sizeof(CHAR))))
                                        {
                                            EnterCriticalSection(&globallock);
                                            pc->pDlg->m_outcoming_total += length;
                                            pc->pDlg->m_outcoming_idle = GetTickCount64();
                                            LeaveCriticalSection(&globallock);
                                            processed = TRUE;
                                        }
                                        else
                                        {
                                            volatile static BOOL ignore = FALSE;

                                            if (!ignore)
                                            {
                                                EnterCriticalSection(&datalock);
                                                colorful_clouds.insert(colorful_clouds.begin(), filename);
                                                LeaveCriticalSection(&datalock);
                                            }
                                        }

                                        LocalFree(data);
                                    }
                                    else
                                    {
                                        EnterCriticalSection(&datalock);
                                        colorful_clouds.insert(colorful_clouds.begin(), filename);
                                        LeaveCriticalSection(&datalock);
                                    }
                                }
                                else
                                {
                                    processed = TRUE;
                                }

                                fr.Close();
                            }
                            else
                            {
                                processed = TRUE;
                            }

                            /* clean up temp file when finish */
                            if (processed)
                            {
                                SetFileAttributes(filename.c_str(), FILE_ATTRIBUTE_NORMAL);
                                DeleteFile(filename.c_str());
                            }
                        }
                    }
                    else
                    {
                        CHAR msg[5] = {'N', 'U', 'L', 'L', '\0'};
                        ::send(sock, msg, sizeof(msg), 0);
                    }
                }

                closesocket(sock);
            }
            else
            {
                closesocket(sock);
            }

            LocalFree(buffer);
        }

        EnterCriticalSection(&globallock);
        pc->pDlg->m_active_collectors--;
        LeaveCriticalSection(&globallock);
        LocalFree(pc);
    }

    return 0;
}


AFX_THREADPROC CCTDlg::ControlThread(LPVOID pParam)
{
    SOCKET sock = INVALID_SOCKET;
    string report;
    string host;
    string base;
    string truckname;
    BOOL primary;
    CCTDlg *pDlg = (CCTDlg *)pParam;
    assert(pDlg != NULL);
    CString hostname(pDlg->cct_hostname);
    CStringA req;
    LPSTR buffer = (LPSTR)LocalAlloc(LMEM_ZEROINIT, (SIZE_T)TRUCK_REQUEST_MAX);
    assert(buffer != NULL);
    mt_debug("Control thread started...");
    hostname.MakeLower();
    wstring whostname(hostname.GetBuffer());
    truckname = ws2s(whostname);

    if (std::find(truck_names.begin(), truck_names.end(), truckname) != truck_names.end())
    {
        mt_debug("Act as primary truck (%s)", truckname.c_str());
        primary = TRUE;
        EnterCriticalSection(&globallock);
        pDlg->m_primary = primary;
        LeaveCriticalSection(&globallock);
    }
    else
    {
        mt_debug("Act as auxiliary truck (%s)", truckname.c_str());
        primary = FALSE;
        EnterCriticalSection(&globallock);
        pDlg->m_primary = primary;
        LeaveCriticalSection(&globallock);
    }

    while (!truck_terminated)
    {
        BOOL ret = FALSE;
        EnterCriticalSection(&globallock);
        report = pDlg->m_report;
        LeaveCriticalSection(&globallock);

        if (report.empty())
        {
            Sleep(USER_TIMER_MINIMUM);
            continue;
        }

        if (primary)
        {
            std::vector<std::string> server_list;

            for (auto item : truck_names)
            {
                if (item != truckname)
                {
                    server_list.push_back(item);
                }
            }

            server_list.shrink_to_fit();

            for (auto item : server_list)
            {
                base = item;
                host = ResolveName((char *)base.c_str());
                req.Format("%s\r\n", STAT_PUSH);
                report = std::string(req.GetBuffer()) + report;

                if (!host.empty())
                {
                    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

                    if (sock != INVALID_SOCKET)
                    {
                        SOCKADDR_IN sa;
                        sa.sin_addr.S_un.S_addr = inet_addr(host.c_str());
                        sa.sin_family = AF_INET;
                        sa.sin_port = htons(TRUCK_SERVER_PORT + 1);

                        if (connect(sock, (SOCKADDR *)&sa, sizeof(SOCKADDR)) == 0)
                        {
                            int size = report.length() + 1;
                            int sent = ::send(sock, report.c_str(), size, 0);

                            if (sent == size)
                            {
                                int nRecv = 0;
                                string datain;
                                BOOL eos = FALSE;
                                timeval tv;
                                FD_SET set;
                                ULONGLONG anchor = GetTickCount64();
                                tv.tv_sec = 0;
                                tv.tv_usec = USER_TIMER_MINIMUM * 1000L;

                                do
                                {
                                    FD_ZERO(&set);
                                    FD_SET(sock, &set);
                                    ret = select(sock, &set, NULL, NULL, &tv);

                                    if (ret > 0)
                                    {
                                        nRecv = ::recv(sock, buffer, (TRUCK_REQUEST_MAX - 1), 0);

                                        if (nRecv > 0)
                                        {
                                            buffer[nRecv] = '\0';
                                            eos = buffer[nRecv - sizeof(CHAR)] == '\0';
                                            datain += string(buffer);
                                        }
                                    }
                                    else if (ret == SOCKET_ERROR)
                                    {
                                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                                    }
                                }
                                while ((!truck_terminated) && (ret != SOCKET_ERROR) && (!eos) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                                if ((nRecv > 0) && (eos))
                                {
                                    CStringA res(datain.c_str());
                                    int pos = res.Find('\n');

                                    if (pos > 0)
                                    {
                                        res = res.Mid(0, pos);
                                        BOOL registered_new = (res.Find("200") >= 0) && (res.Find("OK") >= 0);
                                        BOOL registered_already = (res.Find("302") >= 0) && (res.Find("Found") >= 0);
                                        ret = registered_new || registered_already;

                                        if (ret)
                                        {
                                            string dns = GetFieldContent(datain, "DNS");

                                            if (!dns.empty())
                                            {
                                                string records = base64_decode(dns);

                                                if (!records.empty())
                                                {
                                                    CStringA recordsA(records.c_str());
                                                    EnterCriticalSection(&globallock);
                                                    lmdns_import(recordsA);
                                                    LeaveCriticalSection(&globallock);
                                                }
                                            }
                                        }

                                        if (registered_new)
                                        {
                                            mt_debug("%s registered as primary truck on %s", truckname.c_str(), base.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            Sleep(USER_TIMER_MINIMUM);
                        }

                        closesocket(sock);
                    }
                    else
                    {
                        Sleep(USER_TIMER_MINIMUM);
                    }
                }
                else
                {
                    Sleep(USER_TIMER_MINIMUM);
                }
            }
        }
        else
        {
            BOOL vidata_initialized = FALSE;
            BOOL ota_initialized = FALSE;
            req.Format("%s\r\n", STAT_PUSH);
            report = std::string(req.GetBuffer()) + report;

            for (auto item : truck_list)
            {
                base = item;
                host = ResolveName((char *)base.c_str());

                if (!host.empty())
                {
                    sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

                    if (sock != INVALID_SOCKET)
                    {
                        SOCKADDR_IN sa;
                        sa.sin_addr.S_un.S_addr = inet_addr(host.c_str());
                        sa.sin_family = AF_INET;
                        sa.sin_port = htons(TRUCK_SERVER_PORT + 1);

                        if (connect(sock, (SOCKADDR *)&sa, sizeof(SOCKADDR)) == 0)
                        {
                            int size = report.length() + 1;
                            int sent = ::send(sock, report.c_str(), size, 0);

                            if (sent == size)
                            {
                                int nRecv = 0;
                                string datain;
                                BOOL eos = FALSE;
                                timeval tv;
                                FD_SET set;
                                ULONGLONG anchor = GetTickCount64();
                                tv.tv_sec = 0;
                                tv.tv_usec = USER_TIMER_MINIMUM * 1000L;

                                do
                                {
                                    FD_ZERO(&set);
                                    FD_SET(sock, &set);
                                    ret = select(sock, &set, NULL, NULL, &tv);

                                    if (ret > 0)
                                    {
                                        nRecv = ::recv(sock, buffer, (TRUCK_REQUEST_MAX - 1), 0);

                                        if (nRecv > 0)
                                        {
                                            buffer[nRecv] = '\0';
                                            eos = buffer[nRecv - sizeof(CHAR)] == '\0';
                                            datain += string(buffer);
                                        }
                                    }
                                    else if (ret == SOCKET_ERROR)
                                    {
                                        mt_debug("Failed to select, WSAGetLastError()=%d", WSAGetLastError());
                                    }
                                }
                                while ((!truck_terminated) && (ret != SOCKET_ERROR) && (!eos) && ((GetTickCount64() - anchor) < (TRUCK_TIMEOUT * 1000ULL)));

                                if ((nRecv > 0) && (eos))
                                {
                                    CStringA res(datain.c_str());
                                    int pos = res.Find('\n');

                                    if (pos > 0)
                                    {
                                        res = res.Mid(0, pos);
                                        BOOL registered_new = (res.Find("200") >= 0) && (res.Find("OK") >= 0);
                                        BOOL registered_already = (res.Find("302") >= 0) && (res.Find("Found") >= 0);
                                        ret = registered_new || registered_already;

                                        if (ret)
                                        {
                                            string dns = GetFieldContent(datain, "DNS");
                                            string vidata = GetFieldContent(datain, "VIDATA");
                                            string logota = GetFieldContent(datain, "LOGOTA");

                                            if (!dns.empty())
                                            {
                                                string records = base64_decode(dns);

                                                if (!records.empty())
                                                {
                                                    CStringA recordsA(records.c_str());
                                                    EnterCriticalSection(&globallock);
                                                    lmdns_import(recordsA);
                                                    LeaveCriticalSection(&globallock);
                                                }
                                            }

                                            if (!vidata.empty())
                                            {
                                                string vidatas = base64_decode(vidata);

                                                if (!vidatas.empty())
                                                {
                                                    EnterCriticalSection(&globallock);

                                                    if (!vidata_initialized)
                                                    {
                                                        pDlg->m_vidata_servers = vidatas;
                                                        vidata_initialized = TRUE;
                                                    }
                                                    else
                                                    {
                                                        pDlg->m_vidata_servers += vidatas;
                                                    }

                                                    LeaveCriticalSection(&globallock);
                                                }
                                            }

                                            if (!logota.empty())
                                            {
                                                CStringA ota_opt(logota.c_str());
                                                ota_opt.MakeLower();
                                                BOOL ota = ((ota_opt.Find("true") >= 0) || (ota_opt.Find("yes") >= 0) || (ota_opt.Find("always") >= 0));
                                                EnterCriticalSection(&globallock);

                                                if (!ota_initialized)
                                                {
                                                    pDlg->m_log_ota = ota;
                                                    ota_initialized = TRUE;
                                                }
                                                else
                                                {
                                                    pDlg->m_log_ota = (pDlg->m_log_ota && ota);
                                                }

                                                LeaveCriticalSection(&globallock);
                                            }
                                        }

                                        if (registered_new)
                                        {
                                            mt_debug("%s registered as auxiliary truck on %s", truckname.c_str(), base.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            Sleep(USER_TIMER_MINIMUM);
                        }

                        closesocket(sock);
                    }
                    else
                    {
                        Sleep(USER_TIMER_MINIMUM);
                    }
                }
                else
                {
                    Sleep(USER_TIMER_MINIMUM);
                }
            }
        }

        if (ret)
        {
            ULONGLONG start = GetTickCount64();

            while ((!truck_terminated) && ((GetTickCount64() - start) <= (30UL * 1000UL)))
            {
                Sleep(USER_TIMER_MINIMUM);
            }
        }
        else
        {
            Sleep(USER_TIMER_MINIMUM);
        }
    }

    LocalFree(buffer);
    return 0;
}


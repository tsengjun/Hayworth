// MQM TruckDlg.h : header file
//

#pragma once
#include "afxcmn.h"
#include <iostream>
#include <sstream>
#include <string>
#include <winsock2.h>
#include "afxwin.h"

using namespace std;

typedef enum
{
    LVL_B, /* background */
    LVL_D, /* debug */
    LVL_W, /* warning */
    LVL_A, /* alert */
    LVL_E, /* error */
    LVL_RAW/* raw */
} loglevel_t;

// CCTDlg dialog
class CCTDlg : public CDialog
{
        // Construction
    public:
        CCTDlg(CWnd *pParent = NULL);	// standard constructor

        // Dialog Data
#ifdef AFX_DESIGN_TIME
        enum { IDD = IDD_CCT_DIALOG };
#endif

    protected:
        virtual void DoDataExchange(CDataExchange *pDX);	// DDX/DDV support

        // Implementation
    protected:
        HICON m_hIcon;

        // Generated message map functions
        virtual BOOL OnInitDialog();
        afx_msg void OnPaint();
        afx_msg HCURSOR OnQueryDragIcon();
        DECLARE_MESSAGE_MAP()
    public:
        BOOL m_avoid_update = FALSE;
        BOOL m_primary = FALSE;
        BOOL m_idle_notified = FALSE;
        BOOL m_log_ota = FALSE;
        ULONGLONG m_idle_counter = 0ULL;
        ULONGLONG m_incoming_total = 0ULL;
        ULONGLONG m_incoming_idle = 0ULL;
        ULONGLONG m_outcoming_total = 0ULL;
        ULONGLONG m_outcoming_idle = 0ULL;
        ULONGLONG m_active_clients = 0ULL;
        ULONGLONG m_active_collectors = 0ULL;
        ULONGLONG m_free_space = 0ULL;
        TCHAR cct_temppath[MAX_PATH];
        TCHAR cct_hostname[MAX_PATH];
        CString m_caption;
        string m_report;
        string m_vidata_servers;
        CRichEditCtrl m_message;
        CStatic m_information_frame;
        CStatic m_bottom_logo;
        CButton m_pause;
        CButton m_resume;
        CStatic m_incoming;
        CStatic m_inidle;
        CStatic m_outcoming;
        CStatic m_outidle;
        CStatic m_clients;
        CStatic m_collectors;
        CStatic m_space;
        afx_msg void OnSize(UINT nType, int cx, int cy);
        afx_msg void OnTimer(UINT_PTR nIDEvent);
        afx_msg void OnBnClickedPauseBtn();
        afx_msg void OnBnClickedResumeBtn();
        afx_msg void OnDestroy();
        void InitializeWinsock2();
        void UpdateUiStatus(BOOL paused);
        void UpdateReport(string &report);
        void MessageWindowRedraw();
        void CCTDlg::debug(loglevel_t lvl, TCHAR *format, ...);
        virtual BOOL PreTranslateMessage(MSG *pMsg);

        CWinThread *m_incoming_thread = NULL;
        static AFX_THREADPROC DataIncomingThread(LPVOID pParam);
        static DWORD WINAPI DataIncomingClientThread(LPVOID lpPar);

        CWinThread *m_outcoming_thread = NULL;
        static AFX_THREADPROC DataOutcomingThread(LPVOID pParam);
        static DWORD WINAPI DataOutcomingClientThread(LPVOID lpPar);

        CWinThread *m_control_thread = NULL;
        static AFX_THREADPROC ControlThread(LPVOID pParam);
};

typedef struct
{
    SOCKET sock;
    sockaddr_in sa;
    int sa_len;
    int id;
    CCTDlg *pDlg;
} CLIENT, *pCLIENT;
